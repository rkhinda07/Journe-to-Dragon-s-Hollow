#include <iostream>
#include <string>
using namespace std;

#include "Game.h"

Game::Game() { //ctor
		who = 0;
		won = false;
		liveHeroes = 2;
		int options[5] = { 1, 2, 3, 4, 5 }; //options of rows for Timmy
		int optionsLeft[4];

		//pick a location for Timmy adn add in list of players
		int pick = options[random(5)];
		players.push_back(new Timmy(pick, 1));
		int o = 0;

		for (int i = 1; i <= 5; i++) {	//get all location except Timmy's to pick Harold's
				if (i != pick) {
						optionsLeft[o++] = i;
				}
		}
		//pick a location for Harold and add in list
		players.push_back(new Harold(optionsLeft[random(4)], 1));

		//add the dragon
		players.push_back(new Dragon(3, 25));

		//disp.drawOn(players);
		//disp.print();
}

Game::~Game() {

		disp.drawOn(players);
		disp.print();

		//remove all leftover players
		list<Player*>::iterator itr;
		for (itr = players.begin(); itr != players.end(); ++itr) { //iterate over the list
				deleteCorrect(*itr);
				itr = players.erase(itr);
		}
}

Player* Game::lookup(int x, int y) {// checks if there is a player at a coordinate
	list<Player*>::iterator itr; //iterator
	for (itr = players.begin(); itr != players.end(); ++itr)  {
		int m;
		int n;

		Player* ptr = *itr;
		ptr->setCord(&m, &n);
		if (m == x && n == y)//if same coordinates
			return ptr; //return ptr to the player
		}
		return NULL;
	}


void Game::generateEnemy() {
	int Pos[3] = { 2, 3, 4 }; //possible rows to spawn enemies
	Player *enemy;
	//pick randomly and generate new enemy
	int pick = random(3);
	if(pick == 0)
		enemy = new Dorc(Pos[random(3)], 25);
	else if(pick == 1)
		enemy = new Borc(Pos[random(3)], 25);
	else
	enemy = new Porc(Pos[random(3)], 25);
	//generate and add a new enemy to the list
	players.push_back(enemy);
}

void Game::handleCollisions() { //collision handler
		liveHeroes = 2;
		//go through all objects and match their coordinates
		list<Player*>::iterator itr;
		for(itr = players.begin(); itr != players.end(); ++itr) {
			Player* ptr = *itr;
			int x;
			int y;

			ptr->setCord(&x, &y);

			list<Player*>::iterator cpy = itr;
			for (cpy++; cpy != players.end(); cpy++) {//copy iterator
				Player* sec = *cpy;
				int m;
				int n;

				sec->setCord(&m, &n);
				//if they are the same, create and handle collision
				if (x == m && y == n) {
					Collision(ptr, sec).handle();
				}
			}
		//remove life if hero is dead
		if (ptr->toDraw() == '+') {
			liveHeroes--;
			//remove win flag if hero dies in the endzone
			if (won && 2 <= x && x <= 4 && y == 25 && who == ptr->getType()) {
				won = false;
			}
		}
		//add win flag if hero is alive
		else if (ptr->getType() >= 5 && 2 <= x && x <= 4 && y == 25) {
			won = true;
			who = ptr->getType(); //sets winner
		}
	}
}

void Game::play() { //play function
	liveHeroes = 2;
	won = false;
	while (!won && liveHeroes > 0) {//till no one wins and heroes are alive
		liveHeroes = 0;
		//60% chance to create enemy
		if (random(100) < 60)
			generateEnemy();

		//iterate all players and move them
		list<Player*>::iterator itr;
		for(itr = players.begin(); itr != players.end(); itr++) {
			Player* ptr = *itr;
			//remove killed enemy
			if (ptr->getType() == 0) {
				deleteCorrect(ptr);
				itr = players.erase(itr);
				continue;
			}
			//move only Movable players
			else if (ptr->getType() >= 3) { //enemies or heroes
				if (ptr->getType() >= 5) //if Timmy or Harold
					liveHeroes++;
					Movable* mov = (Movable*) ptr;
					int* corTemp = mov->attemptMove(); //movement to proceed
					int cor[2];

					cor[0] = corTemp[0];
					cor[1] = corTemp[1];

					delete[] corTemp; //del temp array
					mov->setCord(cor[0], cor[1]); //set new coordinates
					//kill enemies at leftmost column
					if (mov->getType() == 3 && cor[1] == 1) {
						mov->setHealth(0);
					}
					//remove enemies
					if (mov->getHealth() <= 0 && mov->toDraw() != '+') { //if enemy dies
						deleteCorrect(ptr);
						itr = players.erase(itr);
						continue;
					}
				}
			}
			//draw the new Hollow
			disp.drawOn(players);
			disp.print();
			//handle collisions
			handleCollisions();
			//game end flag
			if (liveHeroes == 0) { //heroes die
				cout << "The adventurers perished..."<<endl;
						continue;
				}
				//game win
				if (won) {
						cout << (who == 6 ? "Harold" : "Timmy") <<" claims the emerald!!!"<<endl;
						continue;
				}

				cout << "Press ENTER to iterate..."<<endl;

				//wait for user to press enter and iterate
				char c;
				do {
						c = getc(stdin);
				} while (c != '\n');
			}
		}

void Game::deleteCorrect(Player* p) { //deletes players
	//cout<<"game finished and deleted"<<endl;
		int type = p->getType();
		switch (type) {
		case 3: //if enemy
				delete (Enemy*)p;
				break;
		case 0: //if dead
				delete (Enemy*)p;
				break;
		case 5: //if Timmy
				delete (Timmy*)p;
				break;
		case 6: //if Harold
				delete(Harold*)p;
				break;
		case 4: //if Dragon
				delete(Dragon*)p;
				break;
		case 1:
				if (p->getArmor() == 1)
						delete(Timmy*)p;
				else
						delete(Harold*)p;
				break;
		default:
				break;
		}
}
