#include <iostream>
#include <string>
using namespace std;

#include "Mushroom.h"


Mushroom::Mushroom(int x, int y) : Movable(x, y){ //ctor for mushroom
  marker = '%';
  type = 7;
  movSize = 1;
  health = 5;
}

Mushroom::~Mushroom(){}

bool Mushroom::collideWith(Player* p) {
		//cout << "In collision!" << endl;
		if (p == NULL)
				return true;

    int type = p->getType();//get type of colliding player

		//cout << type << endl;
		//walls and Dragon do nothing
		if (type == 5 || type == 6) { //if Harold or Timmy
  			cout<<"Health Boost!!!!"<<endl;
			((Movable *)p)->setHealth(15); //Set their Health back to 15
			die(); //Mushroom dies
			return false;
		}
		else {
			return true;
		}
}

int **Mushroom::getMoves(){ //Movement handler
	int **arr = new int*[1]; //2d array
	arr[0] = new int[2];

	arr[0][0] = x; //coordinates
	arr[0][1] = y;

	return arr;
}

void Mushroom::die(){ //death of mushroom
	marker = ' ';
}
