#include <stdlib.h>
#include <time.h>
#include "Control.h"
//Maib with random implementation

using namespace std;

int main()
{
    srand((unsigned)time(NULL));

    Control c;
    c.launch();
}
