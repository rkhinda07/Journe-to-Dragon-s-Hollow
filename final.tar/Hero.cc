#include <iostream>
#include <string>
using namespace std;

#include "Hero.h"

Hero::Hero(int x, int y) : Movable(x, y) {//Hero ctor
	health = 15;
	movSize = 3;
}
Hero::~Hero(){}

Timmy::Timmy(int x, int y):Hero(x, y) { //Timmy ctor
	marker = 'T';
	strength = 3;
	armor = 3;
	type = 5; //Timmy - Type 3
}
Timmy::~Timmy(){
	//cout<<"dtor"<<endl;
}

Harold::Harold(int x, int y) : Hero(x, y) { //Harold ctor
	marker = 'H';
	strength = 5;
	armor = 1;
	type = 6; //Harold - Type 6
}
Harold::~Harold(){}

bool Hero::collideWith(Player* p) { //collision handler function for heroes
	if (p == NULL)
		return true;
	int type = p->getType();
	if (type == 1 || type == 5 || type == 6) { //if collides with a dead hero, or Timmy or Harold
		return false; //do nothing
	}
	//Dragon kills instantly
	else if (type == 4) {
		die();
		return false;
	}
	//enemies fight health = health - strength + armor
	else if (type == 3) {
		setHealth(health - (p->getStrength() - armor));
		return false;
	}
	else {
		return true;
	}
}

int** Hero::getMoves() {//Movement handler
	movSize = 3;// default moves 3

	if (x - 1 == 0) //uppermost row
		movSize--;
	if (x + 1 == 6) //lowermost row
		movSize--;
	if (y + 1 == 26) //rightmost column
		movSize--;

	int** arr = new int* [movSize]; //2d array for storing positions
	for (int i = 0; i < movSize; i++) {
		arr[i] = new int[2];
	}
	int fl = 0;
	//up-right MOVEMENT
	if (x - 1 != 0) {
		arr[fl][0] = x - 1;
		arr[fl++][1] = y + 1;
	}
	//right MOVEMENT
	if (y + 1 != 26) {
		arr[fl][0] = x;
		arr[fl++][1] = y + 1;
	}
	//bottom-right MOVEMENT
	if (x + 1 != 6) {
		arr[fl][0] = x + 1;
		arr[fl++][1] = y + 1;
	}
	//dont exceed limits
	if (y + 1 == 26) {
		for (int i = 0; i < fl; i++)
			arr[i][1]--;
	}
	return arr;
}

void Hero::die() { //if a hero dies, replace it with + marker
		type = 1; //set its type to 1
		marker = '+';
}
