#include <iostream>
#include <string>
using namespace std;

#include "Display.h"

Display::Display():Array<char>(7, 27) { //Constructs an array of chars with dimensions
	for (int i = 0; i < 7; i++) {
		if (i == 0 || i == 6) {
			for (int j = 1; j < 26; j++){
				arr[i][j] = '-'; //Constructs the upper and lower boundary of the hollow
			}
		}
		arr[i][0] = '|'; //Constructs the left and right boundary of hollow
		arr[i][26] = i < 2 || i > 4 ? '|' : '='; //and doors at the right end
		}
	}

void Display::clear(){ //clears out the array for next iteration
	for (int i = 1; i < 6; i++){
		for (int j = 1; j < 26; j++){
			arr[i][j] = ' ';
		}
	}
}

void Display::drawOn(list<Player*> toDraw){ //draws the character on the hollow board
	clear();
	list<Player*>::iterator itr; //iterator to iterate in the players list
	for(itr = toDraw.begin(); itr != toDraw.end(); itr++) {
		int x;
		int y;
		Player* p = *itr; //each player in the list
		p->setCord(&x, &y); //get coordinates of the player
		if (arr[x][y] == ' '){ //if entry blank, draw its character marker
			arr[x][y] = p->toDraw();
		}
	}
}

void Display::print() { //prints out the hollow on the screen
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 27; j++)
			cout << arr[i][j];
				if (i == 3){
					cout << "*"; //emerald
				}
				cout << endl;
		}
}
