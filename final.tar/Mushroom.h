#ifndef MUSHROOM_H
#define MUSHROOM_H

#include "Player.h"
#include "Movable.h"
//Mushroom class for innovative mode

class Mushroom : public Movable
{
	public:
		Mushroom(int x,int y); //ctor
		~Mushroom();
    bool collideWith(Player* p); //collision Handler
    int** getMoves(); //movement handler
    void die(); //death handler


};
#endif
