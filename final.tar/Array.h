#include <iostream>
using namespace std;
#include <cstdlib>

//template array class
template <class T>
class Array
{
	public:
		Array(int,int); //Array ctor
		~Array(); //Array dtor
		T& operator[](int); //subscript operator

	protected:
		T** arr; //Dynamic Array
		int cols; //Rows and columns in array
		int rows;
};

template <class T>
Array<T>::Array(int rows, int cols){
	this->rows = rows;
	this->cols = cols;

	arr = new T * [rows];  //creates an array with rows and cols
	for (int i = 0; i < rows; ++i)
		arr[i] = new T[cols]; //Dynamic array of dynamic arrays
}
template <class T>
Array<T>::~Array(){
	for (int i = 0; i < rows; i++)
			delete[] arr[i]; //delete the array at an index of array
		delete[] arr; //delete the main array
}
template <class T>
T& Array<T>::operator[](int s){
	return arr[s]; //return the element at index
}
