#ifndef MOVABLE_H
#define MOVABLE_H

#include "Player.h"
#include "helpers.h"
//Movable class for all types of players extending player class
class Movable : public Player
{
	public:
		Movable(int x, int y); //ctor
		virtual int** getMoves() = 0; //abstarct function handling possible moves for a player
		virtual bool collideWith(Player*) = 0; // abstarct function to handle collisions between players
		int* attemptMove(); //function to pick a movement from the possibles and proceed
		void setCord(int, int); //sets new coordinates of a player
		void setHealth(int); //sets new health of a player and calls die if needed
		virtual void die() = 0; //abstarct death handle function


	protected:
		int movSize; //max size of move list


};


#endif
