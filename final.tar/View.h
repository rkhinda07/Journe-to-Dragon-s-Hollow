#ifndef VIEW_H
#define VIEW_H

#include <iostream>
#include <string>
using namespace std;
//view class to display the menu and record user choics

class View
{
  public:
    void showMenu(int&); //prints menu
    void printStr(string); //string print
    void readInt(int&); //reads user input

};

#endif
