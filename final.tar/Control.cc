#include <iostream>
#include <iomanip>
#include <string>
using namespace std;

#include "Control.h"

Control::Control()
{

}

void Control::launch()
{
  int choice;
  while (1) {
    view.showMenu(choice);

    if (choice == 0){
      //cout<<"BYE"<<endl;
      break;
    }

  else if(choice == 1) { //if user chooses 1, play normal game
    G = new Game();
    G->play(); //calls play function from game class
    delete G; //deletes the game and deallocates the memory
  }

  else if(choice == 2) { //Play game in Innovative mode
    //cout<<"here"<<endl;
      I = new Innovative();
      I->play();
      delete I;
      //cout<<"here2"<<endl;

  }




}
}
