#ifndef CONTROL_H
#define CONTROL_H

#include "View.h"
#include "Game.h"
#include "Innovative.h"

//Control class to control the game flow
class Control
{
  public:
    Control();
    void launch(); //launches the game

  private:
    Game *G; //normal game object
    Innovative *I; //Innovative mode game object
    View view; //View object to print the menu and record user options

};

#endif
