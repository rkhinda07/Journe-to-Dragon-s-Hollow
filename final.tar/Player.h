#ifndef PLAYER_H
#define PLAYER_H

//Player class for all player atributes
class Player
{
	public:
		Player(); //ctor
		~Player();
		char toDraw(); //returns marker of player
		int getType(); //returns type of player
		int getHealth(); //getter for health
		int getStrength();//getter for strength
		int getArmor(); //getter for Armor
		void setCord(int* x, int* y); //setter for coordinates

	protected:
		int x; //coordinates
		int y;
		int type; //type of player
		char marker;
		int health;
		int strength;
		int armor;
};

#endif
