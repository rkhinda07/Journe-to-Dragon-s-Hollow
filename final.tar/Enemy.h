#ifndef ENEMY_H
#define ENEMY_H

#include "Movable.h"
#include "Hero.h"

//Enemy class extending movable class for all types of enemies
class Enemy : public Movable
{
	public:
		Enemy(int,int); //ctor
		~Enemy();
		bool collideWith(Player* p); //Collision hanler for all enemy
		int** getMoves() ; //gives possible moves available
		void die(); //death handler
};
//Dragon class
class Dragon : public Movable
{
	public:
		Dragon(int,int); //ctor
		bool collideWith(Player* p); //Collision handler for dragon
		int** getMoves(); //Possible moves for dragon
		void die(); //death handler

	private:
		int moveOffset; //to control motion of dragon
};
//Dorc class extending enemy class
class Dorc : public Enemy
{
	public:
		Dorc(int,int); //ctor
		~Dorc();
};
//Borc class extending enemy class
class Borc : public Enemy
{
	public:
		Borc(int, int);
		~Borc();
};
//Porc class extending enemy class
class Porc : public Enemy
{
	public:
		Porc(int, int);
		~Porc();
};



#endif
