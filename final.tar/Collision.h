#ifndef COLLISION_H
#define COLLISION_H

#include "Player.h"
#include "Movable.h"

//class to handle collisions
class Collision
{
  public:
    Collision(Player* o, Player* t);
		//cause one way collision
		void handle();

  private: 
    Player* one;
		Player* two;
};
#endif
