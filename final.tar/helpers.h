#ifndef HELPERS_H
#define HELPERS_H
//calls rabdom function wherever needed
int random(int max);

#endif
