Name - Ramneek Khinda
ID - 101099146

Files included: 
1.Game.cc
2.Game.h
3.Innovative.cc
4.Innovative.h
5.Control.cc
6.Control.h
7.Player.cc
8.Player.h
9.Movable.cc
10.Movable.h
11.Hero.cc
12.Hero.h
13.Enemy.cc
14.Enemy.h
15.Mushroom.cc
16.Mushroom.h
17.Display.cc
18.Display.h
19.Array.h
20.View.cc
21.View.h
22.Collision.cc
23.Collision.h
24.Random.cc
25.helpers.h
26.main.cc
27.Makefile
28.README.txt

Purpose: Implemented the course knowledge to develop a game using templates and Object Oriented design pattern. The game starts with two players Timmy and Harold trying to win by reaching to the emerald by facing various enemies and a Dragon in the way.

Innovative Feature: Added a new player named "Mushroom" which takes a place randomly on the hollow board. If any of the hero i.e. Timmy or Harold eats or collides with the Mushroom, the hero's lost health restores back to the default health(inspired from SuperMario) and the Mushroom disappears. A total of three Mushrooms gets generated in a gameplay at random positions.Implementing this feature involved the following classes ~ Movable class and Player class

Compiling and Launching: Go to the directory and give command make in the terminal. This creates all the executable and object files. Now to run the executable type ./final and hit enter.A menu to play the game appears. To play Game in noraml mode, press (1). To play in innovative mode, press (2) and when done press(0) to exit.
