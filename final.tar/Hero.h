#ifndef HERO_H
#define HERO_H

#include "Player.h"
#include "Movable.h"

//Class extending movable class and Containing all the heroes
class Hero : public Movable
{
	public:
		Hero(int,int);  //ctor
		~Hero();
		bool collideWith(Player* p); //collision handler
		int** getMoves(); //Movements
		void die(); //death handler
};
//Timmy class extemding Hero class
class Timmy : public Hero
{
	public:
		Timmy(int,int);//ctor
		~Timmy();
};
//Harold class extemding Hero class
class Harold : public Hero
{
	public:
		Harold(int,int);//ctor
		~Harold();

};

#endif
