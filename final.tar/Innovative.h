#ifndef INNOVATIVE_H
#define INNOVATIVE_H


#include "Player.h"
#include "Display.h"
#include "Movable.h"
#include "Hero.h"
#include "Enemy.h"
#include "Collision.h"
#include "Mushroom.h"


//Innocative game control class
class Innovative
{
	public:
		Innovative();
		~Innovative();
    Player* lookup(int x, int y);
    void generateMushroom(); //generates mushrooms
    void generateEnemy();
		void handleCollisions();
		bool play();
		void deleteCorrect(Player* p);

	private:
    Display disp;
    list<Player*> players;
    bool won;
    int liveHeroes;
    int who;

};



#endif
