#include <iostream>
#include <string>
using namespace std;

#include "Player.h"

Player::Player() { //ctor
		marker = ' ';
		health = 0;
		strength = 0;
		armor = 0;
		type = 0;
		x = 0;
		y = 0;
}

Player::~Player(){} //dtor

//simple getters and setters for base class

char Player::toDraw() {return marker;}
int Player::getType() {return type;}
int Player::getHealth(){return health;}
int Player::getStrength(){return strength;}
int Player::getArmor(){return armor;}
void Player::setCord(int* x, int* y) {
		*x = this->x;
		*y = this->y;
}
