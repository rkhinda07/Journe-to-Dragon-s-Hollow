#include <iostream>
#include <string>
using namespace std;

#include "Collision.h"


Collision::Collision(Player* o, Player* t) {
    one = o;  //player 1
    two = t; //player 2
}
void Collision::handle() {
    ((Movable*)one)->collideWith(two); //handles collision bw the players
}
