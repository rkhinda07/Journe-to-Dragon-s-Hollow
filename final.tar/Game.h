#ifndef GAME_H
#define GAME_H

#include "Player.h"
#include "Display.h"
#include "Movable.h"
#include "Hero.h"
#include "Enemy.h"
#include "Collision.h"

#include <list>


//game control class
class Game {
	public:
		Game(); //ctor
		~Game(); //dtor
		Player* lookup(int x, int y); //look for player under the coordinates
		void generateEnemy(); //creates enemies
		void handleCollisions(); //iterate over all players and handle collisions if they overlap
		void play(); //function where game starts
		void deleteCorrect(Player* p);//identify and delete correct player pointer

	private:
		Display disp; //display object (2d array)
		list<Player*> players; //list of players
		bool won;//flag to end game
		int liveHeroes;//heroes counter
		int who; //tracker to find who won the emerald

};



#endif
