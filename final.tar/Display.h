#ifndef DISPLAY_H
#define DISPLAY_H

#include "Player.h"
#include "Array.h"

#include <list>

//Class to print out the Hollow

class Display : public Array<char> {
	public:
		Display(); //display ctor
		void clear();	//clear middle of the Hollow
		void drawOn(list<Player*> toDraw); //draw in the middle of the Hollow.
		void print(); //print the contained 2d array
};

#endif
