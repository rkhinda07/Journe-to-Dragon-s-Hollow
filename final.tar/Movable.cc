#include <iostream>
#include <string>
using namespace std;

#include "Movable.h"

Movable::Movable(int x, int y) { //ctor
		this->x = x;
		this->y = y;
		movSize = 0;
}

int* Movable::attemptMove() {
		int** mov = getMoves(); //gets list of possible moves for a player
		int rm = random(movSize);//pick one of them randomly

		//free dynamic storage
		for (int i = 0; i < movSize; i++) {
				if (i == rm)
						continue;
				delete[] mov[i];
		}

		int* c = mov[rm];
		delete[] mov;

		//return picked coordinates
		return c;
}

void Movable::setCord(int x, int y) { //sets new coordinates
		this->x = x;
		this->y = y;
}

void Movable::setHealth(int h) {
		//if health below 0 , death
		if (h <= 0) {
				die();
		}
		health = h;
}
