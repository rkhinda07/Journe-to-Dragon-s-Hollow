#include <iostream>
#include <string>
using namespace std;

#include "Enemy.h"

Enemy::Enemy(int x, int y) : Movable(x, y) {
	type = 3; //All enemies come under class 3
	health = 5;
}

Enemy::~Enemy(){}

Dorc::Dorc(int x, int y) : Enemy(x, y)
{
	//cout<<"Dorc ctor"<<endl;
	marker = 'd';
	strength = 6 + random(3); //randomly generate strength of Dorc
}

Dorc::~Dorc(){}

Borc::Borc(int x, int y) : Enemy(x, y)
{
	marker = 'b';
	strength = 8 + random(4); //randomly generate strength of Borc
}

Borc::~Borc(){}

Porc::Porc(int x, int y) : Enemy(x, y)
{
	marker = 'p';
	strength = 4 + random(2); //randomly generate strength of Porc
}

Porc::~Porc(){}

bool Enemy::collideWith(Player* p) {//function to handle collisions
	if (p == NULL)
		return true;

	int type = p->getType(); //gets the type of player collding

	//walls and Dragon do nothing to enemies
	if (type == 1 || type == 4) {
		return false;
	}
	//heroes fight and health = health - hero strength
	else if (type >= 5) {
		setHealth(health - p->getStrength());
		return false;
	}
	else {
		return true;
	}
}

int** Enemy::getMoves() { //Movement handling function
	movSize = 3; // 3 possibilities at beginning
	if (x - 1 == 0) //if top  corner row
	movSize--; //reduce the possible moves
	if (x + 1 == 6)//if at bottom row
	movSize--;
	if (y - 1 == 0) //if at leftmost column
	movSize--;
	int** arr = new int* [movSize]; //crates a 2d array of possible moves
		for (int i = 0; i < movSize; i++) {
				arr[i] = new int[2];
		}
		int fl = 0;
		//up-left
		if (x - 1 != 0) {
			arr[fl][0] = x - 1;
			arr[fl++][1] = y - 1;
		}
		//left
		if (y - 1 != 0) {
				arr[fl][0] = x;
				arr[fl++][1] = y - 1;
		}
		//bottom-left
		if (x + 1 != 6) {
				arr[fl][0] = x + 1;
				arr[fl++][1] = y - 1;
		}
		//do not exceed bountries
		if (y - 1 == 0) {
				for (int i = 0; i < fl; i++)
						arr[i][1]++;
		}

		return arr;
}

void Enemy::die() { //if enemy dies
		type = 0; //type becomes 0
		marker = ' '; //set marker to empty space
}



Dragon::Dragon(int x, int y) : Movable(x, y) {
		type = 4; //set type to 4 i.e Dragon
		marker = 'D';
		health = 100;
		moveOffset = 1;  //One possible move, up or down
		movSize = 1;
}
int** Dragon::getMoves() {
		if (x == 2) //if row 2
				moveOffset = 1; //increase the count
		if (x == 4) //if row 4
				moveOffset = -1; //dec the count

		int** arr = new int* [1]; //array of possible moves
		arr[0] = new int[2]; //2d array
		arr[0][0] = x + moveOffset; //column wise movemnet
		arr[0][1] = y; //cols

		return arr;
}

bool Dragon::collideWith(Player* p){
		if (p == NULL)
				return true;
		int type = p->getType();
		if (type == 1 || type == 3) { //if collision with enemy or a dead hero
				return false;
		}
		else if (type >= 5) { //if heroes
				((Movable*)p)->setHealth(0); //set health to 0
				return false;
		}
		else {
				return true;
		}
}

void Dragon::die() { //dragon never dies
	cout << "This shouldn't happen" << endl;
}
