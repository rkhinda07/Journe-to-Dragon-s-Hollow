#include <iostream>
#include <string>
using namespace std;

#include "Innovative.h"
#include "Mushroom.h"


Innovative::Innovative(){
	who = 0;
	won = false;
	liveHeroes = 2;
	int options[5] = { 1, 2, 3, 4, 5 };
	int optionsLeft[4];
	//pick a location for Timmy
	int pick = options[random(5)];
	players.push_back(new Timmy(pick, 1));
	int o = 0;
	for (int i = 1; i <= 5; i++) {	//get all location except Timmy's to pick Harold's
		if (i != pick) {
			optionsLeft[o++] = i;
		}
	}
	players.push_back(new Harold(optionsLeft[random(4)], 1)); //pick a location for Harold
	//add the dragon
	players.push_back(new Dragon(3, 25));
	//adding mushrooms to the players list
	generateMushroom();
	//disp.drawOn(players);
	//disp.print();
}

Innovative::~Innovative() {

		disp.drawOn(players);
		disp.print();

		//remove all leftover objects
		list<Player*>::iterator itr;
		for (itr = players.begin(); itr != players.end(); ++itr) {
				deleteCorrect(*itr);
				itr = players.erase(itr);
		}
}

Player* Innovative::lookup(int x, int y) {
	list<Player*>::iterator itr;
	for (itr = players.begin(); itr != players.end(); ++itr)  {
		int m;
		int n;
		Player* ptr = *itr;
		ptr->setCord(&m, &n);

		if (m == x && n == y)
			return ptr;
		}
		return NULL;
	}


void Innovative::generateEnemy() {
		int Pos[3] = { 2, 3, 4 };

		Player *enemy;
		//pick randomly and generate new enemy
		int pick = random(3);

		if(pick == 0)
			enemy = new Dorc(Pos[random(3)], 25);
		else if(pick == 1)
			enemy = new Borc(Pos[random(3)], 25);
		else
			enemy = new Porc(Pos[random(3)], 25);
		//generate and add a new enemy
		players.push_back(enemy);
}

void Innovative::generateMushroom(){
  //Player *mushroom;
  //mushroom = new Mushroom(3,15);
  int i = 3;

  while((i-- )> 0){ //randomly generate 3 mushrooms
  	players.push_back(new Mushroom(1 + random(5), 1 + random(25)));
  }

  //cout << players.size();

}

void Innovative::handleCollisions() {
		liveHeroes = 2;

		//go through all objects and match their coordinates
		list<Player*>::iterator itr;
		for(itr = players.begin(); itr != players.end(); ++itr) {
			Player* ptr = *itr;
			int x;
			int y;

			ptr->setCord(&x, &y);
			list<Player*>::iterator cpy = players.begin();
			for (; cpy != players.end(); cpy++) {
				Player* sec = *cpy;
				int m;
				int n;
				sec->setCord(&m, &n);
				//if the are the same, create and handle collision
				if (x == m && y == n) {
					Collision(ptr, sec).handle();
				}
			}
			//remove life if hero is dead
			if (ptr->toDraw() == '+') {
				liveHeroes--;
				//remove win flag if hero dies in the endzone
				if (won && 2 <= x && x <= 4 && y == 25 && who == ptr->getType()) {
					won = false;
				}
			}
			//add win flag if hero is alive
			else if (ptr->getType() >= 5 && 2 <= x && x <= 4 && y == 25) {
				won = true;
				who = ptr->getType();
				}
		}
}

bool Innovative::play() {
	liveHeroes = 2;
	won = false;
	while (!won && liveHeroes > 0) {
		liveHeroes = 0;
		//60% chance to create enemy
		if (random(100) < 60)
			generateEnemy();
      //generateMushroom();

		//go throug all objects and move them
		list<Player*>::iterator itr;
		for(itr = players.begin(); itr != players.end(); itr++) {
			Player* ptr = *itr;
			//remove killed enemy safely
			if (ptr->getType() == 0) {
				deleteCorrect(ptr);
				itr = players.erase(itr);
				continue;
			}
			//move only Movable objects
			else if (ptr->getType() >= 3 && ptr->getType() <7) {
				if (ptr->getType() >=5 && ptr->getType() <7 )
					liveHeroes++;
				Movable* mov = (Movable*) ptr;
				int* corTemp = mov->attemptMove();
				int cor[2];

				cor[0] = corTemp[0];
				cor[1] = corTemp[1];

				delete[] corTemp;
				mov->setCord(cor[0], cor[1]);
				//kill enemies at left edge
				if (mov->getType() == 3 && cor[1] == 1) {
					mov->setHealth(0);
				}
				//safely remove enemies
				if (mov->getHealth() <= 0 && mov->toDraw() != '+') {
					deleteCorrect(ptr);
					itr = players.erase(itr);
					continue;
				}
			}
		}
		//draw the new map
		disp.drawOn(players);
		disp.print();
		//handle collisions
		handleCollisions();
		//game end flag
		if (liveHeroes == 0) {
			cout << "The adventurers perished..."<<endl;
			continue;
			}
		//game win flag
		if (won) {
			cout << (who == 6 ? "Harold" : "Timmy") <<" claims the emerald!!!"<<endl;
			continue;
		}

		cout << "Press ENTER to iterate..."<<endl;
		char c; 			//wait for user [ENTER] input
		do {
			c = getc(stdin);
		} while (c != '\n');
		}

	return true;
	}

void Innovative::deleteCorrect(Player* p) {
	//cout<<"game finished and deleted"<<endl;
		int type = p->getType();
		switch (type) {
		case 3:
				delete (Enemy*)p;
				break;
		case 0:
				delete (Enemy*)p;
				break;
		case 5:
				delete (Timmy*)p;
				break;
		case 6:
				delete(Harold*)p;
				break;
		case 4:
				delete(Dragon*)p;
				break;
		case 7: //if mushroom
			    delete(Mushroom*)p;
			    break;
		case 1:
				if (p->getArmor() == 1)
						delete(Timmy*)p;
				else
						delete(Harold*)p;
				break;
		default:
				break;
		}
}
