#include <iostream>
using namespace std;
#include <string>

#include "View.h"

void View::showMenu(int& choice)
{

  cout << endl << endl;
  cout << "Event:"<< endl;
  cout << "  (1) Play game" << endl; //normal game
  cout << "  (2) Play game (innovative mode)" << endl; //innovative mode
  cout << "  (0) Exit" << endl;

  cout << "Enter your selection: ";
  cin >> choice;
  if (choice == 0)
    return;

  while (choice < 1 || choice > 2) { //if wrong choice
    cout << "Enter your selection: ";
    cin >> choice;
  }


}

void View::printStr(string str)
{
  cout << str;
}

void View::readInt(int& n)
{
  cin >> n;
}
